module.exports = {
  name: "checkperm",
  description: "checkperm command",
  execute(message, args){
    
    if(message.member.permissions.has("")){
   message.channel.send(`First argument: ${args}`);
  }
  else {
    message.channel.send('You dont have the permission, sorry.')
  }
  }
}