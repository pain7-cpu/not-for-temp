module.exports = {
  name: "ping",
  description: "ping command",
  execute(message, args){
    
    if(message.member.roles.cache.has("813323443889504276")){
    message.channel.send("pong!");
  }
  else {
    message.channel.send("U need a permission, try again! ")
    message.member.roles.add("813323443889504276").catch(console.error);
  }
  }
}